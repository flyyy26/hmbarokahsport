@extends('layouts.customer')

@section('title', 'Promo - Barokah Sport')

@section('content')

<div class="catalog-container">
    <div class="katalog_top_container">
        <div class="catalog-header">
            <h1>Promo & Diskon</h1>
            <p>Produk-produk dengan harga spesial dari Barokah Sport</p>
        </div>

        {{-- ============================================ --}}
        {{-- FILTER ROW - CUSTOM SELECT --}}
        {{-- ============================================ --}}
        <form id="filter-form" method="GET" action="{{ route('customer.products.promo') }}" class="filter-row">
            @if(request('search'))
                <input type="hidden" name="search" value="{{ request('search') }}">
            @endif

            {{-- KATEGORI --}}
            <span class="filter-label">Kategori</span>
            <div class="custom-select-wrapper" data-name="category">
                <div class="custom-select-trigger">
                    <span class="trigger-text">
                        {{ request('category') ? $categories->firstWhere('id', request('category'))->name ?? 'Semua' : 'Semua' }}
                    </span>
                    <iconify-icon icon="tabler:chevron-down"></iconify-icon>
                </div>
                <div class="custom-select-dropdown">
                    <div class="dropdown-item {{ !request('category') ? 'active' : '' }}" data-value="">
                        <span>Semua</span>
                        <span class="check-icon">✓</span>
                    </div>
                    @foreach ($categories as $category)
                        <div class="dropdown-item {{ request('category') == $category->id ? 'active' : '' }}" 
                             data-value="{{ $category->id }}">
                            <span>{{ $category->name }}</span>
                            <span class="check-icon">✓</span>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="filter-divider"></div>

            {{-- GENDER --}}
            <span class="filter-label">Gender</span>
            <div class="custom-select-wrapper" data-name="gender">
                <div class="custom-select-trigger">
                    <span class="trigger-text">
                        {{ request('gender') ? ucfirst(request('gender')) : 'Semua' }}
                    </span>
                    <iconify-icon icon="tabler:chevron-down"></iconify-icon>
                </div>
                <div class="custom-select-dropdown">
                    <div class="dropdown-item {{ !request('gender') ? 'active' : '' }}" data-value="">
                        <span>Semua</span>
                        <span class="check-icon">✓</span>
                    </div>
                    @foreach ($genders as $gender)
                        <div class="dropdown-item {{ request('gender') == $gender ? 'active' : '' }}" 
                             data-value="{{ $gender }}">
                            <span>{{ ucfirst($gender) }}</span>
                            <span class="check-icon">✓</span>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="filter-divider"></div>

            {{-- UKURAN --}}
            <span class="filter-label">Ukuran</span>
            <div class="custom-select-wrapper" data-name="size">
                <div class="custom-select-trigger">
                    <span class="trigger-text">
                        {{ request('size') ?: 'Semua' }}
                    </span>
                    <iconify-icon icon="tabler:chevron-down"></iconify-icon>
                </div>
                <div class="custom-select-dropdown">
                    <div class="dropdown-item {{ !request('size') ? 'active' : '' }}" data-value="">
                        <span>Semua</span>
                        <span class="check-icon">✓</span>
                    </div>
                    @foreach ($sizes as $size)
                        <div class="dropdown-item {{ request('size') == $size ? 'active' : '' }}" 
                             data-value="{{ $size }}">
                            <span>{{ $size }}</span>
                            <span class="check-icon">✓</span>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="filter-divider"></div>

            {{-- WARNA --}}
            <span class="filter-label">Warna</span>
            <div class="custom-select-wrapper" data-name="color">
                <div class="custom-select-trigger">
                    <span class="trigger-text">
                        {{ request('color') ?: 'Semua' }}
                    </span>
                    <iconify-icon icon="tabler:chevron-down"></iconify-icon>
                </div>
                <div class="custom-select-dropdown">
                    <div class="dropdown-item {{ !request('color') ? 'active' : '' }}" data-value="">
                        <span>Semua</span>
                        <span class="check-icon">✓</span>
                    </div>
                    @foreach ($colors as $color)
                        <div class="dropdown-item {{ request('color') == $color ? 'active' : '' }}" 
                             data-value="{{ $color }}">
                            <span>{{ $color }}</span>
                            <span class="check-icon">✓</span>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="filter-divider"></div>

            {{-- SORT BY --}}
            <span class="filter-label">Urutkan</span>
            <div class="custom-select-wrapper" data-name="sort">
                <div class="custom-select-trigger">
                    <span class="trigger-text">
                        @php
                            $sortOptions = [
                                'newest' => 'Terbaru',
                                'discount_desc' => 'Diskon Terbesar',
                                'price_asc' => 'Harga: Rendah → Tinggi',
                                'price_desc' => 'Harga: Tinggi → Rendah',
                                'name' => 'Nama (A-Z)'
                            ];
                        @endphp
                        {{ $sortOptions[request('sort', 'discount_desc')] ?? 'Diskon Terbesar' }}
                    </span>
                    <iconify-icon icon="tabler:chevron-down"></iconify-icon>
                </div>
                <div class="custom-select-dropdown">
                    <div class="dropdown-item {{ request('sort', 'discount_desc') == 'discount_desc' ? 'active' : '' }}" data-value="discount_desc">
                        <span>Diskon Terbesar</span>
                        <span class="check-icon">✓</span>
                    </div>
                    <div class="dropdown-item {{ request('sort') == 'newest' ? 'active' : '' }}" data-value="newest">
                        <span>Terbaru</span>
                        <span class="check-icon">✓</span>
                    </div>
                    <div class="dropdown-item {{ request('sort') == 'price_asc' ? 'active' : '' }}" data-value="price_asc">
                        <span>Harga: Rendah → Tinggi</span>
                        <span class="check-icon">✓</span>
                    </div>
                    <div class="dropdown-item {{ request('sort') == 'price_desc' ? 'active' : '' }}" data-value="price_desc">
                        <span>Harga: Tinggi → Rendah</span>
                        <span class="check-icon">✓</span>
                    </div>
                    <div class="dropdown-item {{ request('sort') == 'name' ? 'active' : '' }}" data-value="name">
                        <span>Nama (A-Z)</span>
                        <span class="check-icon">✓</span>
                    </div>
                </div>
            </div>

            {{-- RESET FILTER --}}
            @if(request()->anyFilled(['category', 'gender', 'size', 'color', 'sort']))
                <a href="{{ route('customer.products.promo') }}" class="filter-reset">
                    ✕ Reset
                </a>
            @endif

            <span class="filter-count">{{ $products->total() }} produk promo</span>
        </form>
        <button type="button" class="filter-toggle-btn" onclick="openFilterPopup()">
            <iconify-icon icon="tabler:filter"></iconify-icon>
            Filter Produk
            <span class="filter-badge" id="filter-badge" style="display:none;">0</span>
        </button>
    </div>
    <div id="filter-popup" class="filter-popup-overlay">
        <div class="filter-popup">
            {{-- Handle --}}
            <div class="filter-popup-handle"></div>

            {{-- Header --}}
            <div class="filter-popup-header">
                <h3>Filter Produk</h3>
                <button type="button" aria-label="Tutup" class="filter-popup-close" onclick="closeFilterPopup()">✕</button>
            </div>

            {{-- Filter Body --}}
            <div id="filter-popup-body">
                {{-- KATEGORI --}}
                <div class="filter-popup-group">
                    <span class="filter-group-label">Kategori</span>
                    <div class="filter-options" data-filter="category">
                        <div class="filter-option active" data-value="">Semua</div>
                        @foreach ($categories as $category)
                            <div class="filter-option {{ request('category') == $category->id ? 'active' : '' }}" 
                                data-value="{{ $category->id }}">
                                {{ $category->name }}
                            </div>
                        @endforeach
                    </div>
                </div>

                {{-- GENDER --}}
                <div class="filter-popup-group">
                    <span class="filter-group-label">Gender</span>
                    <div class="filter-options" data-filter="gender">
                        <div class="filter-option active" data-value="">Semua</div>
                        @foreach ($genders as $gender)
                            <div class="filter-option {{ request('gender') == $gender ? 'active' : '' }}" 
                                data-value="{{ $gender }}">
                                {{ ucfirst($gender) }}
                            </div>
                        @endforeach
                    </div>
                </div>

                {{-- UKURAN --}}
                <div class="filter-popup-group">
                    <span class="filter-group-label">Ukuran</span>
                    <div class="filter-options" data-filter="size">
                        <div class="filter-option active" data-value="">Semua</div>
                        @foreach ($sizes as $size)
                            <div class="filter-option {{ request('size') == $size ? 'active' : '' }}" 
                                data-value="{{ $size }}">
                                {{ $size }}
                            </div>
                        @endforeach
                    </div>
                </div>

                {{-- WARNA --}}
                <div class="filter-popup-group">
                    <span class="filter-group-label">Warna</span>
                    <div class="filter-options" data-filter="color">
                        <div class="filter-option active" data-value="">Semua</div>
                        @foreach ($colors as $color)
                            <div class="filter-option {{ request('color') == $color ? 'active' : '' }}" 
                                data-value="{{ $color }}">
                                {{ $color }}
                            </div>
                        @endforeach
                    </div>
                </div>

                {{-- URUTKAN --}}
                <div class="filter-popup-group">
                    <span class="filter-group-label">Urutkan</span>
                    <div class="filter-options" data-filter="sort">
                        @php
                            $sortOptions = [
                                'newest' => 'Terbaru',
                                'price_asc' => 'Harga: Rendah → Tinggi',
                                'price_desc' => 'Harga: Tinggi → Rendah',
                                'name' => 'Nama (A-Z)'
                            ];
                        @endphp
                        @foreach ($sortOptions as $value => $label)
                            <div class="filter-option {{ request('sort', 'newest') == $value ? 'active' : '' }}" 
                                data-value="{{ $value }}">
                                {{ $label }}
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            {{-- Actions --}}
            <div class="filter-popup-actions">
                <button type="button" class="btn-reset-filter" onclick="resetAllFilters()">
                    Reset
                </button>
                <button type="button" class="btn-apply-filter" onclick="applyFilters()">
                    Terapkan Filter
                </button>
            </div>
        </div>
    </div>

    {{-- ============================================ --}}
    {{-- PRODUCT GRID --}}
    {{-- ============================================ --}}
    <div class="product_layout">
        @if ($products->isEmpty())
            <div class="empty_state">
                <div class="empty-icon"><iconify-icon icon="akar-icons:search"></iconify-icon></div>
                <p>Belum ada produk yang tersedia.</p>
            </div>
        @else
            <div class="product_layout_grid">
                @foreach ($products as $product)
                    <x-product-card :product="$product" skeletonPrefix="promo" />
                @endforeach
            </div>
        @endif
    </div>

    {{-- PAGINATION --}}
    @if ($products->hasPages())
        <div class="pagination-wrapper">
            {{ $products->links() }}
        </div>
    @endif

</div>

<script>
    var filterState = {
        category: '{{ request('category') ?? '' }}',
        gender: '{{ request('gender') ?? '' }}',
        size: '{{ request('size') ?? '' }}',
        color: '{{ request('color') ?? '' }}',
        sort: '{{ request('sort', 'newest') }}'
    };

    var initialFilterState = Object.assign({}, filterState);

    // 🔥 BUKA POPUP FILTER
    function openFilterPopup() {
        var popup = document.getElementById('filter-popup');
        if (!popup) return;
        
        // Sync state dari URL
        syncFilterStateFromURL();
        
        // Reset aktifasi berdasarkan state
        applyFilterStateToPopup();
        
        popup.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // 🔥 TUTUP POPUP FILTER
    function closeFilterPopup() {
        var popup = document.getElementById('filter-popup');
        if (!popup) return;
        
        popup.classList.remove('active');
        document.body.style.overflow = '';
    }

    // 🔥 SYNC FILTER STATE DARI URL
    function syncFilterStateFromURL() {
        var urlParams = new URLSearchParams(window.location.search);
        
        filterState.category = urlParams.get('category') || '';
        filterState.gender = urlParams.get('gender') || '';
        filterState.size = urlParams.get('size') || '';
        filterState.color = urlParams.get('color') || '';
        filterState.sort = urlParams.get('sort') || 'newest';
    }

    // 🔥 APPLY FILTER STATE KE POPUP
    function applyFilterStateToPopup() {
        var groups = document.querySelectorAll('.filter-popup-group .filter-options');
        
        groups.forEach(function(group) {
            var filterName = group.dataset.filter;
            var selectedValue = filterState[filterName] || '';
            
            var options = group.querySelectorAll('.filter-option');
            options.forEach(function(option) {
                option.classList.remove('active');
                if (option.dataset.value === selectedValue) {
                    option.classList.add('active');
                }
            });
        });
    }

    // 🔥 UPDATE FILTER BADGE
    function updateFilterBadge() {
        var badge = document.getElementById('filter-badge');
        if (!badge) return;
        
        var count = 0;
        if (filterState.category) count++;
        if (filterState.gender) count++;
        if (filterState.size) count++;
        if (filterState.color) count++;
        
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'inline';
        } else {
            badge.style.display = 'none';
        }
    }

    // 🔥 EVENT LISTENER UNTUK FILTER OPTIONS (DI POPUP)
    document.addEventListener('click', function(e) {
        var target = e.target.closest('.filter-popup-group .filter-option');
        if (!target) return;
        
        var group = target.closest('.filter-options');
        if (!group) return;
        
        var filterName = group.dataset.filter;
        
        // Hapus active dari semua di group yang sama
        var options = group.querySelectorAll('.filter-option');
        options.forEach(function(opt) {
            opt.classList.remove('active');
        });
        
        target.classList.add('active');
        
        // Update state
        filterState[filterName] = target.dataset.value;
        
        // Update badge
        updateFilterBadge();
    });

    // 🔥 APPLY FILTERS - SUBMIT FORM
    function applyFilters() {
        var form = document.getElementById('filter-form');
        if (!form) return;
        
        // Hapus input filter lama
        var filterNames = ['category', 'gender', 'size', 'color', 'sort'];
        filterNames.forEach(function(name) {
            var oldInput = form.querySelector('input[name="' + name + '"]');
            if (oldInput) {
                oldInput.remove();
            }
        });
        
        // Tambahkan input baru berdasarkan state
        if (filterState.category) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'category';
            input.value = filterState.category;
            form.appendChild(input);
        }
        
        if (filterState.gender) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'gender';
            input.value = filterState.gender;
            form.appendChild(input);
        }
        
        if (filterState.size) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'size';
            input.value = filterState.size;
            form.appendChild(input);
        }
        
        if (filterState.color) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'color';
            input.value = filterState.color;
            form.appendChild(input);
        }
        
        if (filterState.sort && filterState.sort !== 'newest') {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'sort';
            input.value = filterState.sort;
            form.appendChild(input);
        }
        
        // Tutup popup
        closeFilterPopup();
        
        // Submit form
        form.submit();
    }

    // 🔥 RESET ALL FILTERS
    function resetAllFilters() {
        filterState = {
            category: '',
            gender: '',
            size: '',
            color: '',
            sort: 'newest'
        };
        
        // Update UI
        var groups = document.querySelectorAll('.filter-popup-group .filter-options');
        groups.forEach(function(group) {
            var filterName = group.dataset.filter;
            var options = group.querySelectorAll('.filter-option');
            options.forEach(function(option) {
                option.classList.remove('active');
                if (option.dataset.value === '') {
                    option.classList.add('active');
                }
            });
        });
        
        // Update badge
        updateFilterBadge();
    }

    // 🔥 CLOSE POPUP ON OVERLAY CLICK
    document.getElementById('filter-popup')?.addEventListener('click', function(e) {
        if (e.target === this) {
            closeFilterPopup();
        }
    });

    // 🔥 ESCAPE KEY
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeFilterPopup();
        }
    });

    // 🔥 INIT - Update badge
    document.addEventListener('DOMContentLoaded', function() {
        syncFilterStateFromURL();
        updateFilterBadge();
        
        // Jika ada parameter filter, tampilkan badge
        var hasFilter = filterState.category || filterState.gender || filterState.size || filterState.color;
        if (hasFilter) {
            updateFilterBadge();
        }
    });
</script>

{{-- ============================================ --}}
{{-- JAVASCRIPT - CUSTOM SELECT --}}
{{-- ============================================ --}}
<script>
// ============================================
// CUSTOM SELECT - TOGGLE DROPDOWN
// ============================================

// 🔥 FUNGSI TOGGLE DROPDOWN
function toggleDropdown(trigger) {
    var wrapper = trigger.closest('.custom-select-wrapper');
    if (!wrapper) return;
    
    var dropdown = wrapper.querySelector('.custom-select-dropdown');
    if (!dropdown) return;
    
    var isOpen = dropdown.classList.contains('open');

    // Tutup semua dropdown lain
    var allDropdowns = document.querySelectorAll('.custom-select-dropdown.open');
    allDropdowns.forEach(function(d) {
        if (d !== dropdown) {
            d.classList.remove('open');
            var t = d.closest('.custom-select-wrapper')?.querySelector('.custom-select-trigger');
            if (t) t.classList.remove('open');
        }
    });

    if (isOpen) {
        dropdown.classList.remove('open');
        trigger.classList.remove('open');
    } else {
        dropdown.classList.add('open');
        trigger.classList.add('open');
    }
}

// 🔥 TUTUP DROPDOWN SAAT KLIK DI LUAR
function closeAllDropdowns() {
    var allDropdowns = document.querySelectorAll('.custom-select-dropdown.open');
    allDropdowns.forEach(function(dropdown) {
        dropdown.classList.remove('open');
        var trigger = dropdown.closest('.custom-select-wrapper')?.querySelector('.custom-select-trigger');
        if (trigger) {
            trigger.classList.remove('open');
        }
    });
}

// ============================================
// INITIALIZE
// ============================================
document.addEventListener('DOMContentLoaded', function() {

    // 🔥 EVENT LISTENER UNTUK TRIGGER
    var triggers = document.querySelectorAll('.custom-select-trigger');
    triggers.forEach(function(trigger) {
        trigger.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleDropdown(this);
        });
    });

    // 🔥 SELECT ITEM
    var items = document.querySelectorAll('.dropdown-item');
    items.forEach(function(item) {
        item.addEventListener('click', function(e) {
            e.stopPropagation();
            
            var wrapper = this.closest('.custom-select-wrapper');
            if (!wrapper) return;
            
            var trigger = wrapper.querySelector('.custom-select-trigger');
            var dropdown = wrapper.querySelector('.custom-select-dropdown');
            var name = wrapper.dataset.name;
            var value = this.dataset.value;
            var text = this.querySelector('span')?.textContent || '';

            // Update trigger text
            var triggerText = trigger?.querySelector('.trigger-text');
            if (triggerText) {
                triggerText.textContent = text;
            }

            // Update active state
            if (dropdown) {
                var allItems = dropdown.querySelectorAll('.dropdown-item');
                allItems.forEach(function(d) {
                    d.classList.remove('active');
                });
            }
            this.classList.add('active');

            // Close dropdown
            if (dropdown) dropdown.classList.remove('open');
            if (trigger) trigger.classList.remove('open');

            // 🔥 UPDATE FORM DAN SUBMIT
            var form = document.getElementById('filter-form');
            if (!form) return;
            
            // Hapus input lama jika ada
            var oldInput = form.querySelector('input[name="' + name + '"]');
            if (oldInput) {
                oldInput.remove();
            }

            // Buat input baru
            if (value !== '') {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                input.value = value;
                form.appendChild(input);
            }

            // Submit form
            form.submit();
        });
    });

    // 🔥 TUTUP DROPDOWN SAAT KLIK DI LUAR
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.custom-select-wrapper')) {
            closeAllDropdowns();
        }
    });

    // 🔥 BUY NOW
    window.buyNow = function(productId) {
        fetch('/api/products/' + productId + '/variants', {
            headers: { 'Accept': 'application/json' }
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success && data.variants && data.variants.length > 0) {
                if (typeof openVariantModal === 'function') {
                    window._buyNowMode = true;
                    openVariantModal(productId, 'buy_now');
                }
            } else {
                window._buyNowMode = true;
                if (typeof addToCartDirect === 'function') {
                    addToCartDirect(productId);
                }
            }
        })
        .catch(function() {
            window._buyNowMode = true;
            if (typeof addToCartDirect === 'function') {
                addToCartDirect(productId);
            }
        });
    };

    console.log('🎉 Produk promo siap');
});
</script>

@endsection